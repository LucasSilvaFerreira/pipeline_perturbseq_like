from importlib.metadata import version

from .models import PERTURBO

__version__ = version("perturbo")
